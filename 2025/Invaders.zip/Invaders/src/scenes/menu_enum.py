from enum import Enum

class MenuEnum(Enum):
    MAIN_MENU = 1
    DIFFICULTY_MENU = 2
    RANKING_MENU = 3
    GAME = 4