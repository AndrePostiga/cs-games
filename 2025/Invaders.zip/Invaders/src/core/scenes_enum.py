
class ScenesEnum:
    MAIN_MENU = "main_menu"
    DIFFICULTY_MENU = "difficulty_menu"
    RANKING_MENU = "ranking_menu"
    ENDLESS_LEVEL = "endless_level"